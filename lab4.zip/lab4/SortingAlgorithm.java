/**
 * An interface for a sorting algorithm.
 */

public interface SortingAlgorithm {
 public abstract void sort(Object[] items);
}
