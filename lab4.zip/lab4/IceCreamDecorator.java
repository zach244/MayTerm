// Because we extend IceCream, IceCreamDecorator is-a IceCream

public abstract class IceCreamDecorator extends IceCream {
 public abstract String getDescription();
}
