
public class CherryGarcia extends IceCream {
 private static final double COST = 2.15;
 
 public CherryGarcia() {
  description = "Delicious cherry ice cream";
 }

 public double cost() {
  return COST;
 }

}
