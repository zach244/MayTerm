/**
 * An implementation of IceCreamShop
 */

public class BenAndJerry extends IceCreamShop {

 public IceCream getIceCream(String type) {
  if (type.equals("Chunky Monkey"))
   return new ChunkyMonkey();
  else if (type.equals("Cherry Garcia"))
   return new CherryGarcia();
  else
   return null;
 }
 
}
